public class Util {

    public void imprimirArrayNomesOrdenados(String[] nomes){
        int n = nomes.length;
    
    for (int i = 0; i < n; i++){
        System.out.println(nomes[i] + " ");
    }
    
    System.out.println();
}

}