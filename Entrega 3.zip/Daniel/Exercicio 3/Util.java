public class Util {

    public void imprimirArrayString(String[] array) {
        for (String s : array) {
            System.out.print(s);
        }
        System.out.println();
    }
}
